﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ResZd15_pm;

namespace RootsPln2_pm
{
	class pln2_pm
	{
		static void Main(string[] args)
		{

			Console.WriteLine("RootsPln2_pm      Початкин М.А ноябрь 2014г.");
			Console.WriteLine("Программа нахождения корней многчлена");
			Console.WriteLine("методом половинного деления отрезка");
			Console.WriteLine("c заданой  точностью, до 6 знаков после запятой");
			Console.WriteLine();

			int n = 0;


			while (1 == 1)
			{
				CIPln_pm pln = new CIPln_pm();
				if (pln.n == -1)
				{
					break;
				}
				double c, d;
				d = 3;
				c = pln.Mc4();
				pln.Newton(c, d);
				Console.ReadLine();
			}







		}

		static void inputD(out double x)
		{
			try
			{
				x = Convert.ToDouble(Console.ReadLine());
			}
			catch
			{
				Console.WriteLine("Неверный формат ввода, повторите попытку!!");
				inputD(out x);
			}
		}


	}
}